import{jsx as e}from"react/jsx-runtime";import{F as s}from"./FileUploadForm-DmYGfve4.js";import{L as i}from"./CodeEditor-Cp4g17EF.js";const p=({onChange:o,...n})=>{const r=a=>{try{o(JSON.parse(a))}catch{o({}),console.warn("Invalid json, ignoring value using {}")}};return e(s,{...n,language:i.json,extension:".json",onChange:r})};export{p as J};
//# sourceMappingURL=JsonFileUpload-BSVnFg4G.js.map
