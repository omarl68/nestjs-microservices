import{_ as e,k as o}from"./index-C9t2UlUN.js";import*as m from"react";import{s as i}from"./DataListItemRow-Bimi62Tu.js";const l=s=>{var{children:a,className:t=""}=s,r=e(s,["children","className"]);return m.createElement("div",Object.assign({className:o(i.dataListItemControl,t)},r),a)};l.displayName="DataListControl";export{l as D};
//# sourceMappingURL=DataListControl-BRWG6uCI.js.map
