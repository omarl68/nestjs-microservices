import{dh as n}from"./index-C9t2UlUN.js";const c={dateStyle:"long",timeStyle:"short"};function l(){const{whoAmI:t}=n(),o=t.getLocale();return function(e,a){return e.toLocaleString(o,a)}}export{c as F,l as u};
//# sourceMappingURL=useFormatDate-Yp0qEhJS.js.map
