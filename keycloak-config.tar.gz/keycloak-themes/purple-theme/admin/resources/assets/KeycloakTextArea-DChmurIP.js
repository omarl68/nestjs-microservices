import{jsx as t}from"react/jsx-runtime";import{forwardRef as n}from"react";import{cW as m}from"./index-C9t2UlUN.js";const s=n(({onChange:r,...o},a)=>t(m,{...o,ref:a,onChange:(p,e)=>r?.(e)}));s.displayName="TextArea";export{s as K};
//# sourceMappingURL=KeycloakTextArea-DChmurIP.js.map
