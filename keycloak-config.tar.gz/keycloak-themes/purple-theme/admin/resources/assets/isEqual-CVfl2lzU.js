import{dR as s}from"./index-C9t2UlUN.js";function o(a,r){return s(a,r)}export{o as i};
//# sourceMappingURL=isEqual-CVfl2lzU.js.map
