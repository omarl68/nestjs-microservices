import{jsx as a}from"react/jsx-runtime";import{u as r,a8 as n}from"./index-C9t2UlUN.js";const l=t=>{const{t:o}=r();return a(n,{...t,labelOn:o("on"),labelOff:o("off")})};export{l as D};
//# sourceMappingURL=SwitchControl-KjYluOpZ.js.map
