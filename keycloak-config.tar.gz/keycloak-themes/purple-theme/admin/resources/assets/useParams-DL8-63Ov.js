import{d as s}from"./index-C9t2UlUN.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-DL8-63Ov.js.map
