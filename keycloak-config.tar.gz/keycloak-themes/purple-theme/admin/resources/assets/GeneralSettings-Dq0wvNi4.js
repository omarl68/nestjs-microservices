import{jsxs as s,Fragment as i,jsx as r}from"react/jsx-runtime";import{R as o,D as a}from"./DisplayOrder-Dong-iTt.js";import{C as m}from"./ClientIdSecret-4ICGdsMs.js";const c=({create:e=!0,id:t})=>s(i,{children:[r(o,{id:t}),r(m,{create:e}),r(a,{})]});export{c as G};
//# sourceMappingURL=GeneralSettings-Dq0wvNi4.js.map
